Included files :
    * app.py
    * img.png
    * index.js
    * index.html
    * bonus.html

Required Libraries:
The following libraries are to be installed to run the application:
    * flask
    * os
    * cv2
    
INTRODUCTION
------------------------------------------------------------------------
This project is a python application implemented with flask.

Flask is a lightweight WSGI web application framework. 
It is designed to make getting started quick and easy, with the ability to scale up to complex applications. 
It began as a simple wrapper around Werkzeug and Jinja and has become one of the most popular Python web application frameworks.

Flask offers suggestions, but doesn't enforce any dependencies or project layout. 
It is up to the developer to choose the tools and libraries they want to use. 
There are many extensions provided by the community that make adding new functionalities easy.

###### Installing:

Install and update using pip:
pip install -U Flask

Run the app.py in the development mode.
Open http://127.0.0.1:5000/ ( to view it in the browser.)

Example:

 * Debug mode: on
 * Restarting with stat
 * Debugger is active!
 * Debugger PIN: 129-702-649
 * Running on http://127.0.0.1:5000/ (Press CTRL+C to quit)

[Contributing](https://github.com/pallets/flask/blob/master/CONTRIBUTING.rst)

For guidance on setting up a development environment and how to make a contribution to Flask, see the [contributing guidelines](https://github.com/pallets/flask/blob/master/CONTRIBUTING.rst).

###Steps for task 1:

Once you click on the above link a page will appear on your browser. 
The first task is on the home page where you can see the Original Image and the Segmented image. 
Above the page, there is a slider where you can set the value of the threshold for segmentation.

1. Select threshold value over the slider.
2. Click "Submit".
3. Refresh your page by pressing Clt + Shift + R.
4. An alert box will pop on screen, press "Continue".
5. Observe the changes on the the screen.

Click on 'See the next section' on the same page to view the bonus task.

Preview Output:
[Link](https://github.com/agup0013/Image-Processing/blob/master/Sample1.png)
###Steps for task 2:

You can view a big canvas with a reset and clip button, I have done basic modification in this page to make it more user-friendly.
There are two buttons on the screen:
    * Reset button resets the drawing and clipped image on the screen
    * Clip button clips the image on the below canvas.
    
As a result of being creative, user can clip as many images as they like on the screen, in any shape. 
Drawing the image on canvas is user dependent, so any enclosed image in the drawn shape will get clipped on the screen.
 
#####Follow the below steps to clip an image

1. Click on the canvas, you will see a circular cursor on the screen.
2. Now click multiple times on the canvas to select the shape. 
3. Once you are done with the selection, click "Clip" button.
4. Observe the changes below the image canvas.
5. Repeat steps 2 to 4 to clip multiple images.
6. You can also reset the clipped image and page by clicking on "Reset" button on the top.

Preview Output:
[Link](https://github.com/agup0013/Image-Processing/blob/master/Sample3.png )



