#################### IMPORTING PACKAGES #######################
from flask import Flask, render_template,request
import os
import cv2
###################### UPLOADING PIC ############################
app = Flask(__name__)

picFolder = os.path.join('static', 'pics')
app.config['UPLOAD_FOLDER'] = picFolder
###################### READING IMAGE ############################
img = cv2.imread('static/pics/img.png',0)
####################### FLASK - TASK 1 ###################################

@app.route('/',methods=['GET','POST'])
def modelos():
    if request.method == 'POST':
        pic1 = os.path.join(app.config['UPLOAD_FOLDER'], 'img.png')
        name_of_slider = request.form["name_of_slider"]
        ret, threshold_mask = cv2.threshold(img, int(name_of_slider), 255, cv2.THRESH_BINARY)
        #os.remove("static/pics/mask1.png")
        cv2.imwrite('static/pics/mask1.png', threshold_mask)
        pic2 = os.path.join(app.config['UPLOAD_FOLDER'], 'mask1.png')
        #send the application to upload.html after post request
        return render_template("index.html", user_image=pic1, mask_image=pic2)
    else:
        pic1 = os.path.join(app.config['UPLOAD_FOLDER'], 'img.png')
        pic2 = os.path.join(app.config['UPLOAD_FOLDER'], 'mask1.png')
        # show the index page in case of no request
        return render_template('index.html',user_image=pic1, mask_image=pic2)

########################################### SCRIPT - TASK 2 ############################################
@app.route('/bonus')
def bonus():

    return render_template('bonus.html')

app.run(debug=True)
